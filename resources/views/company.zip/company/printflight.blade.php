<html dir="rtl" lang="ar">
<?php  
$path_image = public_path('addbyme/images/');
$path_image1 = public_path('upload/photo/');?>
<head>
  <!--title-->
   <title>Home-Table</title>
   <!--end of title-->

 <!--meta-->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 <!--end of meta-->

  </head>

<style type="text/css">
body{ font-family: 'sf_pro_displayregular'!important; margin:0px; padding:0px;}

@font-face {
    font-family: 'sf_pro_displayregular';
    src: url('fonts/sf-pro-display-regular-webfont.woff2') format('woff2'), url('fonts/sf-pro-display-regular-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'sf_pro_displaybold';
    src: url('../fonts/sf-pro-display-bold-webfont.woff2') format('woff2'), url('../fonts/sf-pro-display-bold-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}


  </style>











<body style="margin:0px; padding:0px;">


<table class="table-responsive" style="width:100%;border-spacing: 0; ">
   <thead>
        <tr>
          <td class="maintd" style="display: inline-flex; color:#253858;"> 
          <img class="borderimages" src="{{$path_image1.$company->photo}}" style=" width:100px;    height: 100px;        display: inline-block;    border-radius: 50px;    overflow: hidden;">
            <b style="padding-top: 19px;    padding-left: 20px;    font-size: 27px;">{{$company->travel_agency_name}}</td>
           <td class="coman" style="font-size: 22px; color:#253858;"><b>التاريخ: <?php echo Date('d/m/Y');?></b></td>
        </tr>

        <tr class="coman1" style="margin-top:30px; display: block;">
          <td><b style="font-size: 22px; color:#253858;">تفاصيل تأكيد الحجز: <a href="#" style="color:#4A7EE2; font-weight:600; letter-spacing:1px; text-decoration:none;"> #{{$request->appointmentid}}</a></b></td>
        </tr>
   </thead>
</table>

<table class="table-responsive" style="width:100%;border-spacing: 0; ">
   <tbody>
      <tr class="Outboundcolor" style="margin-top:30px; margin-bottom:30px; display:block;">
        <td><b style="font-size:22px; font-weight:600; background-color:#FD5352; border-radius:10px; padding:10px 20px; color:#fff; cursor:pointer;">الذهاب</b> <img src="{{$path_image.'air2.png'}}" style="position:relative; top:13px;"></td>
      </tr>
  </tbody>
</table>

<table class="table-responsive"  style="width:100%;border-spacing: 0; ">
  <tbody class="maintra1">
     <tr class="bgtra" style="background-color:#EFEFEF; padding:4px;">
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">من</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">الى</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">رقم الطيران</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">شركة الطيران</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">التاريخ</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">وقت المغادرة</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">وقت الوصول</td>
     </tr>

          <tr>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->o_country}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->o_city}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$request->outbound}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->o_airline}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->o_from}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->o_departure_time}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->o_arrival_time}}</td>
     </tr>

   </tbody>
  
</table>

<?php if($package->inbound == 'on'){ ?>
<table class="table-responsive"  style="width:100%;border-spacing: 0; ">
   <tbody>
     <tr class="Outboundcolor color1" style="margin-top:30px; margin-bottom:30px; display:block;">
      <td><b style="font-size:22px; font-weight:600; background-color:#409A16; border-radius:10px; padding:10px 20px; color:#fff; cursor:pointer;">الرجوع</b> <img src="{{$path_image.'air3.png'}}" style="position:relative; top:13px;"></td>

     </tr>
    </tbody>
</table>

<table class="table-responsive"  style="width:100%;border-spacing: 0; ">
  <tbody class="maintra1">
     <tr class="bgtra" style="background-color:#EFEFEF; padding:4px;">
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">من</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">الى</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">رقم الطيران</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">شركة الطيران</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">التاريخ</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">وقت المغادرة</td>
        <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">وقت الوصول</td>
     </tr>

          <tr>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->i_country}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->i_city}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$request->inbound}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->i_airline}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->i_from}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->i_departure_time}}</td>
       <td style="font-size:20px; font-weight:600; color:#253858;     padding: 10px;">{{$package->i_arrival_time}}</td>
     </tr>

   </tbody>
  
</table>
<?php }?>

<table class="table-responsive mainfooter" style="width:100%;border-spacing: 0;  margin-top:40px; ">
   <thead>
        <tr class="footername">
            <td style="width:70%">
              <b style="font-size:22px; font-weight:600; color:#253858;">اسماء المسافرين</b><br/>
              <?php foreach($visitors as $visitor){?>
              <span style="display:block;font-size:18px; font-weight:600; color:#253858;     padding-left: 10px;     margin-top: 2px;">{{$visitor->first_name}}/{{$visitor->last_name}}</span><br/>
              <?php }?>
            </td>
            <td style="width:30%">
              <b  style="font-size:22px; font-weight:600; color:#253858;">التكلفة</b><br/>
              <a href="#" class="Price2" style="display: block;    background-color: #F2F2F2;    padding: 12px;    font-size: 22px;    font-weight:600;    width: 32%;border-radius: 50px;  text-align: center;   color: #253858; text-decoration:none;">${{$request->pdfprice}}</a>
            </td>
         </tr>

   </thead>
</table>
<table class="table-responsive mainfooter" style="width:100%;border-spacing: 0;  margin-top:40px; text-align:center">
   <thead>
        <tr class="footername">
            <td style="width:100%">
              <b style="font-size:22px; font-weight:600; color:#253858;">رقم هاتف الشركة : {{$company->travel_agency_phone_number}}</b><br/>
            </td>
         </tr>

   </thead>
</table>

  <footer style=" position: fixed; bottom: 200px; left: 0px; right: 0px; height: 0px; z-index: 5;">
        <table class="table-responsive" style="width:100%;border-spacing: 0;line-height: 30pt; ">
          <tbody >
            <tr  style=" width:100%;">
              <td style=" width:100%;">
                <p  style="font-size: 22px;font-weight:600;">يرجى الملاحظة</p>
              </td>
            </tr>
            <tr style="background-color:#F8F8F8;width:100%;">
              <td style=" width:100%;">
                <p  style="font-size: 22px;font-weight:600;width:100%;">-يغلق الكاونتر قبل ساعة من مغادرة الطائرة</p>
                <p  style="font-size: 22px;font-weight:600;">-الوزن 30 كغم</p>
              </td>
            </tr>
            <tr style="text-align:center;width:100%;">
              <td style=" width:100%;color:red;text-align:center;">
                <p  style="font-size: 22px;font-weight:600;">يجب الحضور قبل 3 ساعات الى المطار</p>
              </td>
            </tr>
          </tbody>
        </table>
        <div style="background-color:black;height:1px;width:100%;text-align:center;">
        </div>
        <table class="table-responsive" style="width:100%;border-spacing: 0; ">
          <tbody>
            <tr style=" width:100%;">
              <td style=" width:70%;text-align:center;">
                <p  style="font-size: 22px;font-weight:600;">في حالة وجود أي مشكلة يرجى الأتصال بالأرقام التالية</p>
              </td>
              <td style=" width:8%;">
                <p  style="font-size: 22px;font-weight:600;">بغداد</p>
                <p  style="font-size: 22px;font-weight:600;">تركيا</p>
              </td>
              <td style=" width:22%;">
                <p  style="font-size: 22px;font-weight:600;"><img src="{{$path_image.'phone.png'}}">6040</p>
                <p  style="font-size: 22px;font-weight:600;"><img src="{{$path_image.'phone.png'}}">02125843464</p>
              </td>
            </tr>
          </tbody>
        </table>
  </footer>
</body>
</html>