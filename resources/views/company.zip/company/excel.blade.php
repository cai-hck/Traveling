<table class="table table-bordered table-hover">
    <thead>
    <tr>
        <th>#</th>
        <th>Reference Booking Number</th>
        <th>Package ID</th>
        <th>Company name(Provide)</th>
        <th>Company name(Appointment)</th>
        <th>Date of booking</th>
        <th>Name of persons</th>
        <th>Passport Number</th>
        <th>DOB</th>
        <th>Airline</th>
        <th>Airline</th>
    </tr>
    </thead>
    <tbody>
    <?php $count = 0; ?>
    @foreach($appointments as $row)
        <?php $count++; ?>
        <tr>
            <td>{{$count}}</td>
            <td>{{$row->id}}</td>
            <td>{{$row->package_id}}</td>
            <td>{{$row->travel_agency_name}}</td>
            <td>{{$row->name}}</td>
            <td>{{$row->created_at}}</td>
            <td>{{$row->first_name}} {{$row->ln}}</td>
            <td>{{$row->pssport_no}}</td>
            <td>{{$row->day_of_birth}}</td>
            <td>{{$row->airline}}</td>
            <td>{{$row->airline_1}}</td>
        </tr>
    @endforeach
     </tbody>
</table>